﻿namespace CustomSaber.Data
{
    public enum ColorType
    {
        LeftSaber,
        RightSaber,
        CustomColor
    }
}
