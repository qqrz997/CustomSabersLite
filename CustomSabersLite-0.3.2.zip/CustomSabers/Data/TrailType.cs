﻿namespace CustomSaber.Data
{
    public enum TrailType
    {
        Custom,
        Vanilla,
        None
    }
}
